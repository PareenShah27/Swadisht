﻿using System.ComponentModel.DataAnnotations;

namespace Recipe_Recom_System.Models
{
    public class Cuisine
    {
        [Key] public int CuisineId { get; set; }
        public string CuisineName { get; set; } = string.Empty;
        public ICollection<Recipe> Recipes { get; set; }
    }
}
