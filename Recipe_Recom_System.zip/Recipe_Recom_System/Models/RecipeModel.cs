﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Recipe_Recom_System.Models
{
    public class Recipe
    {
        [Key] public int RecipeId { get; set; }
        public string RecipeName { get; set; } = string.Empty;
        public int CuisineId { get; set; }
        public string DetailedIngredients { get; set; } = string.Empty;
        public string Instructions { get; set; } = string.Empty;
        public int CookTime { get; set; }
        public string ImageURL { get; set; } = string.Empty;

        public Cuisine Cuisine { get; set; }

        public ICollection<RecipeIngredientMap> RecipeIngredientMaps { get; set; }
    }
}
