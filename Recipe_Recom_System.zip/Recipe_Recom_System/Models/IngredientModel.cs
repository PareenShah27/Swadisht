﻿using System.ComponentModel.DataAnnotations;

namespace Recipe_Recom_System.Models
{
    public class Ingredient
    {
        [Key] public int IngredientId { get; set; }
        public string IngredientName { get; set; } = string.Empty;
        public ICollection<RecipeIngredientMap> RecipeIngredientMaps { get; set; }
    }
}
