﻿using Microsoft.EntityFrameworkCore;
using System.Data.Common;

namespace Recipe_Recom_System.Models
{
    public class RecipeDbContext : DbContext
    {
        public RecipeDbContext(DbContextOptions dbContextOptions) : base(dbContextOptions)
        {
            
        }

        public DbSet<Recipe> Recipes { get; set; }
        public DbSet<Ingredient> Ingredients { get; set; }
        public DbSet<Cuisine> Cuisines { get; set; }
        public DbSet<RecipeIngredientMap> RecipeIngredientMaps { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<RecipeIngredientMap>()
                .HasKey(m => new { m.RecipeId, m.IngredientId });

            modelBuilder.Entity<RecipeIngredientMap>()
                .HasOne(m => m.Recipe)
                .WithMany(a => a.RecipeIngredientMaps)
                .HasForeignKey(m => m.RecipeId);

            modelBuilder.Entity<RecipeIngredientMap>()
                .HasOne(m => m.Ingredient)
                .WithMany(a => a.RecipeIngredientMaps)
                .HasForeignKey(m => m.IngredientId);

            modelBuilder.Entity<Recipe>()
                .HasOne(c => c.Cuisine)
                .WithMany(r => r.Recipes)
                .HasForeignKey(c => c.CuisineId);
        }

    }
}
