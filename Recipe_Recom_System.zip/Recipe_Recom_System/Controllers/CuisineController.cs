﻿using Microsoft.AspNetCore.Mvc;
using Recipe_Recom_System.Models;
using Microsoft.EntityFrameworkCore;

namespace Recipe_Recom_System.Controllers
{
    [Route("api/Cuisine")]
    public class CuisineController : ControllerBase
    {
        private readonly RecipeDbContext _context;
        public CuisineController(RecipeDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<IActionResult> GetCuisines()
        {
            var cuisines = await _context.Cuisines.ToListAsync();
            if(cuisines == null || cuisines.Count == 0)
            {
                return BadRequest();
            }

            return Ok(cuisines);
        }
    }
}
