﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Recipe_Recom_System.Models;

namespace Recipe_Recom_System.Controllers
{
    [Route("api/Recipe")]
    [ApiController]
    public class RecipeController : ControllerBase
    {
        private readonly RecipeDbContext _context;
        public RecipeController(RecipeDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<IActionResult> GetAllRecipes()
        {
            var recipes = await _context.Recipes.ToListAsync();

            return Ok(recipes);
        }

        [HttpGet("{id:int}")]
        public async Task<IActionResult> GetRecipeById([FromRoute] int id)
        {
            var recipe = await _context.Recipes.FindAsync(id);
            if(recipe == null)
            {
                return NotFound();
            }

            return Ok(recipe);
        }

    }
}
